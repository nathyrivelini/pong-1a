function setup() {
  createCanvas(600, 400);
}
function draw() {
  background("black");
  circle(xBolinha, yBolinha, diametro);
  xBolinha += velocidadexBolinha;
  yBolinha += velocidadeyBolinha;
  if (xBolinha + raio > width || xBolinha - raio < 0) {velocidadexBolinha *= -1;}
  if (yBolinha + raio > height || yBolinha - raio < 0) {velocidadeyBolinha *= -1;}
  
  rect(xRaquete, yRaquete, raqueteAltura, raqueteComprimento);
  if (keyIsDown(DOWN_ARROW)) {yRaquete += 5;}
  if (keyIsDown(UP_ARROW)) {yRaquete -= 5;}
  if (yRaquete < 0) {yRaquete -= yRaquete;}
  if (yRaquete + raqueteComprimento > 400) {yRaquete -= 5; }
  if (xBolinha - raio < xRaquete + raqueteAltura &&
    yBolinha - raio < yRaquete + raqueteComprimento &&
    yBolinha + raio > yRaquete) {velocidadexBolinha *= -1;}
  rect(xRaqueteOponente, yRaqueteOponente, raqueteAltura, raqueteComprimento);
  yRaqueteOponente = yBolinha - raqueteComprimento / 2;
  if (xBolinha + raio > xRaqueteOponente + raqueteAltura &&
    yBolinha + raio > yRaqueteOponente - raqueteComprimento &&
    yBolinha + raio < yRaqueteOponente) {velocidadexBolinha *= -1;}
  textSize(30);
  text(meusPontos, 20, 30);
  text(pontosOponente, 550, 30);
  fill("white", 102, 153);
  if (xBolinha > 590) { meusPontos += 1;}
  if (xBolinha < 10) {pontosOponente += 1;}
}

let xBolinha = 300;
let yBolinha = 200;
let diametro = 20;
let raio = 10;
let velocidadexBolinha = 6;
let velocidadeyBolinha = 6;

let xRaquete = 5;
let yRaquete = 150;
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let raqueteComprimento = 90;
let raqueteAltura = 10;
let meusPontos = 0;
let pontosOponente = 0;

